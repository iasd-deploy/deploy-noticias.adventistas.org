<?php

require_once dirname(__FILE__) . '/../IASD__Master__test.php';

class IASD_Query__test extends IASD__Master__test {
	function setUp() {
		parent::setUp();
	}
}








