<?php

require_once '_Widget_test.php';

class IASD_ListaDePosts_FormAppearance__test extends IASD_ListaDePosts__Widget_test {

}