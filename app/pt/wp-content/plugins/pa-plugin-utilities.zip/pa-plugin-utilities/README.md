== ARCHIVES DISPONÍVEIS NO TEMA ==

Archive de galerias de imagens - /sala-de-imprensa/galerias (pt_BR)
Archive de galerias de imagens - /sala-de-prensa/galerias (es_ES)

Archive de galerias de vídeos - /sala-de-imprensa/videos (pt_BR)
Archive de galerias de videos - /sala-de-prensa/videos (es_ES)

== Changelog ==

== 1.20.2 =

- Colocando filtro para trocar a url de 'deptos.adventistas.org.s3.amazonaws.com' para 'deptos.adventistas.org'.

== 1.20.1 =

- Remove um alerta no Menu Walker

== 1.20.0 =

- Atualiza lógica p/ o plugin ficar compatível com o plugin Elementor

== 1.19.1 =

- Retirando chamada void da função lgpd

== 1.19.0 =

- Adicionando novo formato de banner de cookies por arquivo JS

== 1.18.13 =

- Ajustes.

== 1.18.12 =

- Nova regra de cookies.

== 1.18.11 =

- Ajustando possível falha em sites que não tenham subdomínios em sua URL.

== 1.18.10 =

- Ajuste na persistência correta do dominio.
- Gravando de forma mais ampla o cookies para todos os sites do mesmo dominio, descartando a segmentação dos dubdominios.

== 1.18.9 =

- ????

== 1.17.1 =

- Adiciona no widget slide de serviços a coluna full
- Ajuste de versão

== 1.16.9 =

- Ajuste de versão

== 1.16.7 =

- Ajuste no nome e descrição do widget do Feliz7Play

== 1.16.6 =

- Ajuste na tradução

== 1.16.5 =

- Ajuste no redirect do idioma do btn da widget do f7

== 1.16.3 =

- Add evento do google analytics nos links da widgets do f7;

== 1.16.2 =

- Retirada do titulo da widgtes banner f7;

== 1.16.1 =

- Ajuste do carregamento do javascrpt;

== 1.16.0 =

- Adiciona nova widget de banner publicitário do feliz 7 play;

== 1.15.0 =

- Adiciona a capacidade de fornecer conteúdo no REST API das taxonomias xtt-pa-owner e xtt-pa-colecoes;

== 1.14.4 =

- Adiciona uma verificação no botão de compartilhamento do Whatsapp.

== 1.14.3 =

- Ajusta botões de compartilhamento.

== 1.14.0 =

- Adiciona a tag hreflang no header.

== 1.13.6 =

- Ajusta widget "IASD: Imagem" habilitando o botão salvar quando a imagem é trocada.

== 1.13.5 =

- Adiciona o parametro video_url na saida JSON.

== 1.13.4 =

- Adiciona o parametro de paginação na saida JSON.

== 1.13.3 =

- Ajuste no warning do código do GA.

== 1.13.2 =

- Limpeza no código da trigger que ativa o botão salvar do widget.

== 1.13.1 =

- Habilita botão salvar no IASD: Lista de Post quando tem alteração no conteúdo.

== 1.13.0 =

- Habilita REST API nos videos.

== 1.12.7 =

- Altera a URL do encontre uma igreja p/ suporte do HTTPS.

== 1.12.6 =

- Ajuste no replace do nome da campanha e no site de referencia de clique no banner global.

== 1.12.5 =

- Modifica a lógica da criação do usuario suporte.internetdsa

== 1.12.0 =

- Adiciona banner heder global nav API.

== 1.11.0 =

- Adiciona campos no widget da educação.

== 1.10.1 =

- Adiciona iten no arquivo de tradução que estava faltando. Mostrar mais - Archive - thema ASN

== 1.10.0 =

- Adiciona função que cria a página de busca automaticamente.

== 1.9.1 =

- Ajuste no codigo do facebook pixel.

== 1.9.0 =

- Inlcui codigo do facebook pixel.

== 1.8.1 =

- Ajuste no formulário de busca global.

== 1.8.0 ==

- Inclui o script do hotjar.

== 1.7.3 =

- Ajuste em um notice do form_content_taxonomies.php.

== 1.7.2 =

- Ajuste em um notice do IASD_Sidebar.class.php.

== 1.7.1 =

- Correção do modulo CURL.

== 1.7.0 =

- Nova widget de intagram.

== 1.6.7 =

- Ajuste no link da widgtes encontre uma igreja.

== 1.6.6 =

- Ajuste no link da widgtes encontre uma igreja.

== 1.6.5 =

- Ajuste no ano do copyright no footer.

== 1.6.4 =

- Ajuste na altura variável do widget IASD Facebook Box.

== 1.6.3 =

- Ajuste no widget da CPB.

== 1.6.2 =

- Ajuste nas traduções de alguns slugs.

== 1.6.1 =

- Inclusão do "Lista de galeria de imagens" ao widget Lista de posts. (by: Rodrigo Palheiro)

== 1.6.0 =

- Adiciona o widget CPB: Interessados em Matrícula.

== 1.5.1 =

- Corrige os thumbnails do widget "IASD: Lista de Posts" na view grid\*.

== 1.5.0 =

- Adiciona no widget "Lista de Posts" o formato "Slider ASN".

== 1.4.1 =

- Melhorias no script do GA da Sede Proprietária.

== 1.4.0 =

- Habilita a possibilidade de inclusão de um código do GA na Sede Proprietária. Depende do plugin ACF.

== 1.3.3 =

- Correçao nas imagens do widget "IASD: Lista de Posts" que não estavam aparecendo.

== 1.3.2 =

- Correçao temporaria para erros widgets versao wp =< 4.4

== 1.3.1 =

- Ajuste na api para feed de conteúdos.

== 1.3.0 =

- Corrige método \_\_construct() nos widgets. O método foi deprecated na versão 4.3

== 1.2.0 =

- Adiciona usuário padrão p/ super admin.

== 1.1.8 =

- Atualiza metodo ajax get_json_content.

== 1.1.7 =

- Libera a tag iframe para os usuários.

== 1.1.6 =

- Ajusta a imagen pin.png que estava retornando 404 no widget "IASD: Lista de Posts".

== 1.1.5 =

- Desativa o widget "IASD: Por-do-sol"

== 1.1.4 =

- Renomeia o arquivo clog.txt => README.md
- Retira o "Continue Reading" que estava aparecendo em alguns sites.

== 1.1.3 =

- Ajuste no nome do arquivo reamde.txt.

== 1.1.2 =

- Habilita as sedes proprietárias na edição dos posts.

== 1.1.1 =

- Ajuste no slider dos colunistas.

== 1.1.0 =

- Desativa função truncate do PHP.
- Adiciona mensagem para o usuário configurar sua sede proprietária.
- Melhorias no widget "IASD: Por-do-sol".
- Inclui a opção da sede proprietára no perfil do usuário.
- Ajustes nos links que estavam gerando erro 404 no ASN.
- Permite que qualquer site forneça conteúdo no formato JSON.
- Adiciona segurança adicional no cliente de taxonomias.
- Ajuste no widget da Rádio e TV Novo Tempo.

== 1.0.21 =

- Fix na galeria de imagens que estava dando problemas com o php < 5.3

== 1.0.20 =

- Fix em um empty que estava dando problemas com o php < 5.5

== 1.0.19 =

- Fix em Warnings do PHP

== 1.0.18 =

- Ativa o cookie no widget "IASD: Por-do-sol"
- Ajusata no widget "IASD: Por-do-sol" para ser funcional no AWS

== 1.0.17 =

- Corrige a altura do textarea do widget "IASD: Texto".

== 1.0.16 =

- Desativa o cookie do widget do por-do-sol.

== 1.0.15 =

- Adiciona um fix nas categorias.
- Ajustes no widget de por-do-sol.
- Corrige o css da legenda nas imagens das galerias.
- Ajuste no widget da Rádio e TV Novo Tempo.
- Adiciona uma funcionalidade onde permite os editores alterar o comportamento do widget "IASD: Lista de Posts" pelo font-end (BETA).
- Adiciona novos campos no feed JSON.

== 1.0.14 =

- Adiciona o post type "Pages" ao lista de post.
- Adiciona Categoria no mapa de taxonomias.
- Ajuste na colunagem quando usamos o widget "IASD: Texto"
- Ajuste na exibição das taxonomias no widget "IASD: Lista de Posts". Em algumas situações, ele trazia todas as taxonomias do site.
- Deploy inicial da feature "Navegação entre Sedes". Para teste, colocar os parametros na URL: ?update=true&nav=true
- Inclusão do post type "Revista"
- Fix no título do widget "IASD: Texto"

== 1.0.13 =

- Disponibiliza o conteúdo do site em Json via GET/POST
- Habilita categorias para as páginas
- Corrige o posicionamento dos widget
- Adiciona o filtro quinzenal no widget "IASD: Lista de Posts"
- Corrige um bug no widget "IASD: Lista de Posts" relacionado as galerias de imagens

== 1.0.12 =

- Permite que o widget "IASD: Lista de Posts" filtre conteúdos locais usando as tags/categorias
- Habilita as tags/categorias para administradores/super administradores.
- Adiciona o nome da sede regional no cabeçalho do thema "IASD - Tema Sedes"
- Adiciona o widget "IASD: Imagem"
- O filtro das Sedes Regionais no widget "IASD: Lista de Posts", não traz o conteúdo das sedes filhas
- Ajuste no horário do widget "IASD: Por-do-sol"

== 1.0.11 =

- Ajusta as miniaturas das imagens no widget "IASD: Lista de Posts" quando seleciona uma região/editoria
- Ajusta os títulos no widget "IASD: Lista de Posts" quando selcionado “Grid de 5 posts”
- Ajuste as miniaturas no widget "IASD: Lista de Posts" quando selecionado “Lista com miniaturas e 1 destaque video”
- Ajuste no botão flutuante “Voltar”
- Tradução do botão curtir no widget “IASD: Facebook box”
- Obrigatoriedade da taxonomia “Editoria”

== 1.0.10 =

- Ajusta os thumbs das imagens no widget "IASD: Lista de Posts"

== 1.0.9 =

- Ajusta o tamanho das imagens no widget "IASD: Lista de Posts"

== 1.0.8 =

- Ajusta bug que não mostrava thumbnails de vídeos no widget "IASD: Lista de Posts".
- Atualizado script para mostrar automaticamente a janela com o link para voltar.
- Desativa categorias e tags do menu admin da tela de editar posts.
- Cria menu para post type control e action para restringir.

= 1.0.7 =

- Ajuste em um termo do português.

= 1.0.6 =

- Inclusão do script do GoSquared global.

= 1.0.5 =

- Ajustes nas colunas do amdin do video na listagem de posts no admin

= 1.0.4 =

- Ajustes nas colunas da lista de posts no admin

= 1.0.3 =

- Ajustes no player da TV e Rádio Novo Tempo e Nuevo Tiempo.

= 1.0.2 =

- Ajustes no player da TV e Rádio Novo Tempo e Nuevo Tiempo.
- Ajustes em algumas traduções do Espanhol.

= 1.0.1 =

- Ajustes em algumas traduções do Espanhol.
