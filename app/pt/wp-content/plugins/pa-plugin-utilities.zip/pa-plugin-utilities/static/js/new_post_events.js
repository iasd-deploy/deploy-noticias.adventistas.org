jQuery( document ).ready(function() {

	if( jQuery('#in-xtt-pa-owner-' + args.sedes_owner_id).length && args.sedes_owner_id) {
		jQuery('#in-xtt-pa-owner-' + args.sedes_owner_id).prop('checked', true);

	}

});