jQuery( document ).ready(function() {

	if( jQuery('#xtt-pa-ownerdiv').length && args.hide_owner) {
		jQuery('#xtt-pa-ownerdiv').hide();
	}

});